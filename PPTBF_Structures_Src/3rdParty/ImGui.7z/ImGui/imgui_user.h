// requires:
// defining IMGUI_INCLUDE_IMGUI_USER_H and IMGUI_INCLUDE_IMGUI_USER_INL
// at the project level

#pragma once
#ifndef IMGUI_USER_H_
#define IMGUI_USER_H_

#include "./addons/imgui_user.h"

#endif //IMGUI_USER_H_

